<?php

namespace Database\Seeders;

use App\Models\Offer;
use DB;
use Illuminate\Database\Seeder;

class OffersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
            //  // Define the number of records to insert
            //  $numberOfRecords = 10;

            //  // Generate and insert sample data into the 'offers' table using a for loop
            //  for ($i = 1; $i <= $numberOfRecords; $i++) {
            //      DB::table('offers')->insert([
            //          'image' => 'sample_image_' . $i . '.jpg',
            //          'title_ar' => 'عرض ' . $i,
            //          'title_en' => 'Offer ' . $i,
            //          'description_ar' => 'وصف العرض ' . $i,
            //          'description_en' => 'Offer description ' . $i,
            //          'status' => true,
            //          'created_at' => now(),
            //          'updated_at' => now(),
            //      ]);
            //  }

    }
}
