<?php

namespace Database\Seeders;

use App\Models\City;
use Illuminate\Database\Seeder;

class CitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        City::create([
            'name_ar' => 'الرياض',
            'name_en' => 'Al-Riyad',
        ]);

        City::create([
            'name_ar' => 'المدينة',
            'name_en' => 'Al-Madinah',
        ]);

        City::create([
            'name_ar' => 'مكة',
            'name_en' => 'Makkah',
        ]);
    }
}
