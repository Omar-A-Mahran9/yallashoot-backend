<?php

namespace Database\Seeders;

use App\Models\Color;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class ColorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Color::create([
        "name_ar" => "ابيض",
        "name_en" => "white",
        "hex_code" => "#ffffff",
        "image" => null,
        ]);

        Color::create([
            "name_ar" => "اسود",
            "name_en" => "black",
            "hex_code" => "#000000",
            "image" => null,
          ]);
    }
}
