<?php

namespace Database\Seeders;

use App\Models\Career;
use Illuminate\Database\Seeder;

class CareerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $careers = [
            [
                'id' => 1,
                'title_ar' => 'هل يمكنني بيع سياراتي',
                'title_en' => 'هل يمكنني بيع سياراتي',
                'city_id' => '1',
                'work_type' => 'full-time',
            ],
            [
                'id' => 2,
                'title_ar' => 'هل يمكنني بيع سياراتي',
                'title_en' => 'هل يمكنني بيع سياراتي',
                'city_id' => '1',
                'work_type' => 'full-time',
            ]
        ];

        foreach ($careers as $career)
        {
            Career::create($career);
        }
    }
}
