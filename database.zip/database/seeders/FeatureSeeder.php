<?php

namespace Database\Seeders;

use App\Models\Feature;
use Illuminate\Database\Seeder;

class FeatureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $features = [
            [
                'id' => 1,
                'name_ar' => 'اعلان',
                'name_en' => 'ads',
            ],
            [
                'id' => 2,
                'name_ar' => 'اعلان',
                'name_en' => 'ads',
            ]
        ];

        foreach ($features as $feature) {
            Feature::create($feature);
        }
    }
}
