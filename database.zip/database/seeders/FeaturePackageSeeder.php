<?php

namespace Database\Seeders;

use App\Models\FeaturePackage;
use Illuminate\Database\Seeder;

class FeaturePackageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $featurePackages = [
            [
                'id' => 1,
                'feature_id' => 1,
                'package_id' => 1,
                'value' => 2,
            ],
            [
                'id' => 2,
                'feature_id' => 1,
                'package_id' => 2,
                'value' => 5,

            ],
            [
                'id' => 3,
                'feature_id' => 1,
                'package_id' => 3,
                'value' => 10,
            ],

        ];
        foreach ($featurePackages as $featurePackage) {
            FeaturePackage::create($featurePackage);
        }
    }
}
